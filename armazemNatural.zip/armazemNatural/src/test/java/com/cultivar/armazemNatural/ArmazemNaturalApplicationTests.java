package com.cultivar.armazemNatural;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArmazemNaturalApplicationTests {

	@Test
	void contextLoads() {
	}

}
